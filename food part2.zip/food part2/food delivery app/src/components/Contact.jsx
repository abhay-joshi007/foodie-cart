const Contact=()=>{
    return(
            <h1>Contact Us</h1>
    );
}
export default Contact;



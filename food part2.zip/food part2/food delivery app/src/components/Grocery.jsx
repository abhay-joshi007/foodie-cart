const Grocery=()=>{
    return(
        <h1 >Our inventory is empty</h1>
    );
}
export default Grocery;